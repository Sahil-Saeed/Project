// This file would handle all API calls to the Node.js backend.
// In a single-file setup, this can be part of a larger file, but for structure
// we'll keep it separate.

const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Fetches a list of universities from the backend.
 * @returns {Promise<Array>} A promise that resolves to an array of university objects.
 */
export const getUniversities = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/universities`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to fetch universities:", error);
    return [];
  }
};

/**
 * Sends user data to the AI service to get a prediction.
 * @param {object} userData - The user's academic and personal data.
 * @returns {Promise<object>} A promise that resolves to the prediction results.
 */
export const getUniversityPredictions = async (userData) => {
  try {
    const response = await fetch(`${API_BASE_URL}/predict-university`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to get prediction:", error);
    return null;
  }
};
