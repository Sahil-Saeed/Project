import React, { useState } from 'react';

const Dashboard = ({ user }) => {
  const [recommendations, setRecommendations] = useState([
    { name: "University of California, Berkeley", score: "95%" },
    { name: "Stanford University", score: "92%" },
    { name: "Massachusetts Institute of Technology (MIT)", score: "88%" },
  ]);

  return (
    <div className="w-full max-w-4xl mx-auto p-8 bg-white rounded-xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800">Welcome, {user?.name}!</h2>
        <p className="text-gray-500">Your personalized university recommendations are here.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold text-blue-600 mb-2">{rec.name}</h3>
            <p className="text-gray-700">Admission Score: <span className="font-bold text-green-600">{rec.score}</span></p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
