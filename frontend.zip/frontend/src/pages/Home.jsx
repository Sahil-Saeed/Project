import React, { useState, useMemo } from 'react';

const colleges = [
  {
    id: 1,
    name: "University of California, Berkeley",
    city: "Berkeley",
    images: ["https://placehold.co/600x400/007bff/ffffff?text=UC+Berkeley+1", "https://placehold.co/600x400/007bff/ffffff?text=UC+Berkeley+2"],
    description: "A leading public research university and a founding member of the Association of American Universities. It is known for its rigorous academics and free-thinking spirit. It offers a wide range of undergraduate and graduate programs.",
    reviews: ["Excellent faculty and vibrant campus life.", "The location is fantastic, lots of opportunities.", "Very competitive, but worth it for the education."],
  },
  {
    id: 2,
    name: "Stanford University",
    city: "Stanford",
    images: ["https://placehold.co/600x400/800000/ffffff?text=Stanford+1", "https://placehold.co/600x400/800000/ffffff?text=Stanford+2"],
    description: "One of the world's leading research universities, renowned for its academic strength, wealth, and proximity to Silicon Valley.",
    reviews: ["Top-notch research facilities.", "Beautiful campus and great weather.", "The network is unparalleled."],
  },
  {
    id: 3,
    name: "Massachusetts Institute of Technology (MIT)",
    city: "Cambridge",
    images: ["https://placehold.co/600x400/a31f34/ffffff?text=MIT+1", "https://placehold.co/600x400/a31f34/ffffff?text=MIT+2"],
    description: "A private land-grant research university in Cambridge, Massachusetts. Known for its strong science and engineering programs.",
    reviews: ["Unmatched engineering programs.", "Very intense, but you learn so much.", "A great place for innovation."],
  },
  {
    id: 4,
    name: "Harvard University",
    city: "Cambridge",
    images: ["https://placehold.co/600x400/c7303e/ffffff?text=Harvard+1", "https://placehold.co/600x400/c7303e/ffffff?text=Harvard+2"],
    description: "A private Ivy League research university in Cambridge, Massachusetts. Established in 1636, it is the oldest institution of higher learning in the United States.",
    reviews: ["The history and prestige are incredible.", "Excellent resources and a powerful alumni network.", "A truly world-class education."],
  },
  {
    id: 5,
    name: "Harvard University",
    city: "Cambridge",
    images: ["https://placehold.co/600x400/c7303e/ffffff?text=Harvard+1", "https://placehold.co/600x400/c7303e/ffffff?text=Harvard+2"],
    description: "A private Ivy League research university in Cambridge, Massachusetts. Established in 1636, it is the oldest institution of higher learning in the United States.",
    reviews: ["The history and prestige are incredible.", "Excellent resources and a powerful alumni network.", "A truly world-class education."],
  },
  {
    id: 6,
    name: "Harvard University",
    city: "Cambridge",
    images: ["https://placehold.co/600x400/c7303e/ffffff?text=Harvard+1", "https://placehold.co/600x400/c7303e/ffffff?text=Harvard+2"],
    description: "A private Ivy League research university in Cambridge, Massachusetts. Established in 1636, it is the oldest institution of higher learning in the United States.",
    reviews: ["The history and prestige are incredible.", "Excellent resources and a powerful alumni network.", "A truly world-class education."],
  },
];

const CollegeCard = ({ college, onClick }) => {
  return (
    <div
      onClick={() => onClick(college)}
      className="relative bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
      style={{
        animation: 'card-entry 0.5s ease-out',
        animationFillMode: 'forwards',
      }}
    >
      <img src={college.images[0]} alt={college.name} className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110" />
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{college.name}</h3>
        <p className="text-sm text-gray-500">{college.city}</p>
      </div>
    </div>
  );
};

const CollegeModal = ({ college, onClose }) => {
  if (!college) return null;

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 z-50 flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-95 hover:scale-100" onClick={e => e.stopPropagation()}>
        <div className="p-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>{college.name}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {college.images.map((image, index) => (
              <img key={index} src={image} alt={`${college.name} photo ${index + 1}`} className="w-full h-48 object-cover rounded-lg shadow-sm" />
            ))}
          </div>
          <div className="prose">
            <h3 className="text-xl font-semibold text-gray-700 mt-4">Description</h3>
            <p>{college.description}</p>
            
            <h3 className="text-xl font-semibold text-gray-700 mt-4">Reviews</h3>
            <ul className="list-disc pl-5 space-y-2">
              {college.reviews.map((review, index) => (
                <li key={index} className="text-gray-600">{review}</li>
              ))}
            </ul>
          </div>
          <div className="flex justify-end mt-8">
            <button
              onClick={onClose}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-6 rounded-full transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedCollege, setSelectedCollege] = useState(null);

  const filteredColleges = useMemo(() => {
    if (!selectedCity) {
      return colleges;
    }
    return colleges.filter(college => college.city.toLowerCase().includes(selectedCity.toLowerCase()));
  }, [selectedCity]);

  const openModal = (college) => {
    setSelectedCollege(college);
  };

  const closeModal = () => {
    setSelectedCollege(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
        Explore Universities
      </h2>
      
      <div className="mb-8 flex justify-center">
        <input
          type="text"
          placeholder="Filter by city..."
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.target.value)}
          className="p-3 w-full max-w-md rounded-full shadow-inner border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredColleges.length > 0 ? (
          filteredColleges.map((college) => (
            <CollegeCard key={college.id} college={college} onClick={openModal} />
          ))
        ) : (
          <p className="col-span-full text-center text-gray-500">No colleges found in that city.</p>
        )}
      </div>

      <CollegeModal college={selectedCollege} onClose={closeModal} />
      
      <style>{`
        @keyframes card-entry {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default Home;
