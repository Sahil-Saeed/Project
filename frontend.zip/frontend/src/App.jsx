import React, { useState, useEffect, useMemo } from 'react';
import Image from '../src/assets/harvard.png';

// --- Placeholder Data ---
const initialColleges = [
  {
    id: 1,
    name: "University of California, Berkeley",
    city: "Berkeley",
    ranking: 1,
    images: ["https://placehold.co/600x400/007bff/ffffff?text=UC+Berkeley+1", "https://placehold.co/600x400/007bff/ffffff?text=UC+Berkeley+2"],
    description: "A leading public research university and a founding member of the Association of American Universities. It is known for its rigorous academics and free-thinking spirit.",
    reviews: ["Excellent faculty and vibrant campus life.", "The location is fantastic, lots of opportunities."],
  },
  {
    id: 2,
    name: "Stanford University",
    city: "Stanford",
    ranking: 2,
    images: ["https://placehold.co/600x400/800000/ffffff?text=Stanford+1", "https://placehold.co/600x400/800000/ffffff?text=Stanford+2"],
    description: "One of the world's leading research universities, renowned for its academic strength, wealth, and proximity to Silicon Valley.",
    reviews: ["Top-notch research facilities.", "Beautiful campus and great weather."],
  },
  {
    id: 3,
    name: "Massachusetts Institute of Technology (MIT)",
    city: "Cambridge",
    ranking: 3,
    images: ["https://placehold.co/600x400/a31f34/ffffff?text=MIT+1", "https://placehold.co/600x400/a31f34/ffffff?text=MIT+2"],
    description: "Known for its strong science and engineering programs.",
    reviews: ["Unmatched engineering programs.", "Very intense, but you learn so much."],
  },
  {
    id: 4,
    name: "Harvard University",
    city: "Cambridge",
    ranking: 4,
    images: ["https://placehold.co/600x400/c7303e/ffffff?text=Harvard+1", "https://placehold.co/600x400/c7303e/ffffff?text=Harvard+2"],
    description: "The oldest institution of higher learning in the United States, known for history and prestige.",
    reviews: ["The history and prestige are incredible.", "Excellent resources and a powerful alumni network."],
  },
   {
    id: 4,
    name: "Harvard University",
    city: "Cambridge",
    ranking: 4,
    images: ["https://placehold.co/600x400/c7303e/ffffff?text=Harvard+1", "https://placehold.co/600x400/c7303e/ffffff?text=Harvard+2"],
    description: "The oldest institution of higher learning in the United States, known for history and prestige.",
    reviews: ["The history and prestige are incredible.", "Excellent resources and a powerful alumni network."],
  },
];

// --- Reusable Components ---

const CollegeCard = ({ college, onClick }) => {
  return (
    <div
      onClick={() => onClick(college)}
      className="relative bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105 group"
      style={{ animation: 'card-entry 0.5s ease-out', animationFillMode: 'forwards' }}
    >
      <img 
        src={Image} 
        alt={college.name} 
        className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110" 
        onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/600x400/555555/ffffff?text=Image+Unavailable"; }}
      />
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{college.name}</h3>
        <p className="text-sm text-gray-500">{college.city} | Rank: {college.ranking}</p>
      </div>
    </div>
  );
};

const CollegeModal = ({ college, onClose }) => {
  if (!college) return null;

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 z-50 flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-95 hover:scale-100" onClick={e => e.stopPropagation()}>
        <div className="p-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>{college.name}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {college.images.map((image, index) => (
              <img key={index} src={image} alt={`${college.name} photo ${index + 1}`} className="w-full h-48 object-cover rounded-lg shadow-sm" />
            ))}
          </div>
          <div className="prose">
            <h3 className="text-xl font-semibold text-gray-700 mt-4">Description</h3>
            <p className='text-gray-600'>{college.description}</p>
            
            <h3 className="text-xl font-semibold text-gray-700 mt-4">Reviews</h3>
            <ul className="list-disc pl-5 space-y-2">
              {college.reviews.map((review, index) => (
                <li key={index} className="text-gray-600">{review}</li>
              ))}
            </ul>
          </div>
          <div className="flex justify-end mt-8">
            <button
              onClick={onClose}
              className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-6 rounded-full transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Page Components ---

const ExplorePage = () => {
  const [selectedCity, setSelectedCity] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortCriteria, setSortCriteria] = useState('ranking');
  const [selectedCollege, setSelectedCollege] = useState(null);

  const filteredAndSortedColleges = useMemo(() => {
    let filtered = initialColleges;

    // 1. Filter by City
    if (selectedCity) {
      filtered = filtered.filter(college => college.city.toLowerCase().includes(selectedCity.toLowerCase()));
    }
    
    // 2. Filter by Name Search
    if (searchQuery) {
      filtered = filtered.filter(college => college.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }

    // 3. Sort
    filtered.sort((a, b) => {
      if (sortCriteria === 'ranking') {
        return a.ranking - b.ranking; // Ascending rank (lower is better)
      } else if (sortCriteria === 'name') {
        return a.name.localeCompare(b.name); // Alphabetical
      } else if (sortCriteria === 'city') {
         return a.city.localeCompare(b.city);
      }
      return 0;
    });

    return filtered;
  }, [selectedCity, searchQuery, sortCriteria]);

  const openModal = (college) => setSelectedCollege(college);
  const closeModal = () => setSelectedCollege(null);

  const availableCities = useMemo(() => {
    const cities = initialColleges.map(c => c.city);
    return [...new Set(cities)].sort();
  }, []);

  return (
    <div className="container mx-auto px-4 py-8 w-full max-w-7xl">
      <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
        Explore Top Universities
      </h2>
      
      {/* Filters and Controls */}
      <div className="flex flex-col md:flex-row gap-4 mb-10 p-6 bg-white rounded-xl shadow-md">
        {/* Search by Name */}
        <input
          type="text"
          placeholder="Search by college name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="p-3 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"
        />

        {/* Filter by City */}
        <select
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.target.value)}
          className="p-3 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="">Filter by City (All)</option>
          {availableCities.map(city => (
            <option key={city} value={city}>{city}</option>
          ))}
        </select>

        {/* Sort */}
        <select
          value={sortCriteria}
          onChange={(e) => setSortCriteria(e.target.value)}
          className="p-3 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="ranking">Sort by Rank</option>
          <option value="name">Sort by Name</option>
          <option value="city">Sort by City</option>
        </select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredAndSortedColleges.length > 0 ? (
          filteredAndSortedColleges.map((college) => (
            <CollegeCard key={college.id} college={college} onClick={openModal} />
          ))
        ) : (
          <p className="col-span-full text-center text-gray-500 text-lg">
            No colleges match your current filters. Try adjusting your search or city filter.
          </p>
        )}
      </div>

      <CollegeModal college={selectedCollege} onClose={closeModal} />
      
      <style>{`
        @keyframes card-entry {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

const RecommendationFormPage = ({ setCurrentPage }) => {
  const [formData, setFormData] = useState({
    cgpa: '',
    gradeLevel: '',
    major: '',
    testScore: '',
    extracurriculars: ''
  });
  const [transcriptFile, setTranscriptFile] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setTranscriptFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage('Submitting data for AI recommendation...');

    // In a real application, you would:
    // 1. Upload the file (transcriptFile) to a secure storage (e.g., Firebase Storage).
    // 2. Send the form data (formData) and the file's storage URL to the Node.js backend API.
    
    console.log("Recommendation Data:", formData);
    console.log("Transcript File:", transcriptFile ? transcriptFile.name : 'No file uploaded');

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2500)); 

    setIsSubmitting(false);
    setMessage('Recommendation request submitted successfully! Check your Dashboard for results soon.');
    // Optionally redirect to dashboard after a delay
    setTimeout(() => setCurrentPage('dashboard'), 3000);
  };

  const inputClass = "p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full";

  return (
    <div className="w-full max-w-3xl mx-auto p-8 bg-white rounded-xl shadow-xl">
      <h2 className="text-3xl font-bold text-gray-800 text-center mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
        Get Your Personalized Recommendation
      </h2>
      <p className="text-gray-500 text-center mb-8">Fill in your academic details to let our AI match you with the perfect campus.</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div>
            <label className="block text-gray-700 font-medium mb-1" htmlFor="cgpa">Current CGPA / Grade Average</label>
            <input
              type="number"
              step="0.01"
              min="0"
              max="5"
              id="cgpa"
              name="cgpa"
              value={formData.cgpa}
              onChange={handleChange}
              placeholder="e.g., 3.8 or 92%"
              className={inputClass}
              required
            />
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1" htmlFor="gradeLevel">Current Class / Grade Level</label>
            <input
              type="text"
              id="gradeLevel"
              name="gradeLevel"
              value={formData.gradeLevel}
              onChange={handleChange}
              placeholder="e.g., High School Senior, 12th Grade, B.Tech 3rd Year"
              className={inputClass}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-1" htmlFor="major">Desired Major / Field of Study</label>
          <input
            type="text"
            id="major"
            name="major"
            value={formData.major}
            onChange={handleChange}
            placeholder="e.g., Computer Science, Mechanical Engineering, Business"
            className={inputClass}
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-1" htmlFor="testScore">Standardized Test Scores (Optional)</label>
          <input
            type="text"
            id="testScore"
            name="testScore"
            value={formData.testScore}
            onChange={handleChange}
            placeholder="e.g., 1450 SAT, 32 ACT"
            className={inputClass}
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-1" htmlFor="extracurriculars">Key Extracurriculars / Achievements</label>
          <textarea
            id="extracurriculars"
            name="extracurriculars"
            value={formData.extracurriculars}
            onChange={handleChange}
            placeholder="Mention your top achievements, leadership roles, or projects."
            rows="3"
            className={inputClass + " resize-none"}
          ></textarea>
        </div>

        {/* File Upload for Transcript/Documents */}
        <div>
          <label className="block text-gray-700 font-medium mb-2">Upload Transcript/Grade Report (Image/PDF)</label>
          <label className="cursor-pointer flex items-center p-3 border-2 border-dashed border-blue-400 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <span className="text-blue-600 font-semibold">
              {transcriptFile ? transcriptFile.name : 'Click to select file...'}
            </span>
            <input
              type="file"
              onChange={handleFileChange}
              className="hidden"
              accept=".pdf,image/*"
            />
          </label>
          {transcriptFile && (
            <p className="text-sm text-gray-500 mt-2">File ready: {transcriptFile.name} ({(transcriptFile.size / 1024 / 1024).toFixed(2)} MB)</p>
          )}
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl transition-all duration-200 transform hover:scale-[1.01] shadow-lg disabled:bg-gray-400"
        >
          {isSubmitting ? 'Processing...' : 'Generate My Recommendation'}
        </button>
      </form>

      {message && (
        <div className={`mt-6 p-4 rounded-lg text-center font-medium ${isSubmitting ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
          {message}
        </div>
      )}
    </div>
  );
};

const DashboardPage = ({ user }) => {
  const [recommendations, setRecommendations] = useState([
    { name: "University of California, Berkeley", score: "95%", match: 'High' },
    { name: "Stanford University", score: "92%", match: 'High' },
    { name: "Massachusetts Institute of Technology (MIT)", score: "88%", match: 'Medium' },
    { name: "University of Toronto", score: "75%", match: 'Medium' },
    { name: "University of Waterloo", score: "60%", match: 'Low' },
  ]);
  
  const getMatchColor = (match) => {
      switch(match) {
          case 'High': return 'text-green-600 border-green-300';
          case 'Medium': return 'text-yellow-600 border-yellow-300';
          case 'Low': return 'text-red-600 border-red-300';
          default: return 'text-gray-600 border-gray-300';
      }
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-8 bg-white rounded-xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800">Welcome, {user?.name}!</h2>
        <p className="text-gray-500">Your personalized university recommendations are here.</p>
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-gray-50 p-5 rounded-lg shadow-sm border-l-4 border-blue-500 flex justify-between items-center transition-shadow hover:shadow-md">
            <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-1">{rec.name}</h3>
                <p className="text-sm text-gray-500">Admission Score: <span className="font-bold">{rec.score}</span></p>
            </div>
            <div className={`py-1 px-3 rounded-full text-sm font-bold border ${getMatchColor(rec.match)}`}>
                {rec.match} Match
            </div>
          </div>
        ))}
      </div>
      
      {recommendations.length === 0 && (
          <p className="text-center text-gray-500 mt-8">No recommendations yet. Use the "Recommend me" tool to generate your list!</p>
      )}
    </div>
  );
};


// --- Main App Component ---
const App = () => {
  const [currentPage, setCurrentPage] = useState('explore');
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    // Simulate user login
    setUser({ name: 'Jane Doe', email: 'jane.doe@example.com' });
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage user={user} />;
      case 'recommend':
        return <RecommendationFormPage setCurrentPage={setCurrentPage} />;
      case 'explore':
      default:
        return <ExplorePage setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans antialiased flex flex-col">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-800" style={{ fontFamily: 'Poppins, sans-serif' }}>EduNavigator</h1>
          <nav>
            <button
              onClick={() => setCurrentPage('explore')}
              className={`text-gray-600 hover:text-blue-500 px-3 py-2 rounded-md transition-colors font-medium ${currentPage === 'explore' ? 'bg-blue-50 text-blue-600 font-semibold' : ''}`}
            >
              Explore
            </button>
            <button
              onClick={() => setCurrentPage('dashboard')}
              className={`text-gray-600 hover:text-blue-500 px-3 py-2 rounded-md transition-colors font-medium ${currentPage === 'dashboard' ? 'bg-blue-50 text-blue-600 font-semibold' : ''}`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setCurrentPage('recommend')}
              className={`bg-blue-600 text-white hover:bg-blue-700 ml-4 py-2 px-4 rounded-full transition-all duration-200 transform hover:scale-105 shadow-md`}
            >
              Recommend me
            </button>
          </nav>
        </div>
      </header>
      <main className="flex-1 p-4 flex flex-col items-center">
        {renderPage()}
      </main>
    </div>
  );
};

export default App;
